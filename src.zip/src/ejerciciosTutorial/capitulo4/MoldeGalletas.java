package cap�tulo4;

public class MoldeGalletas {
	
	public int numero;
	/**
	 * 
	 * @param valor
	 */
	public MoldeGalletas(int valor) {
		numero = valor;
	}
	/**
	 * 
	 */
	public void miNumero() {
		System.out.println("Mi n�mero es: " + numero);
	}
}
