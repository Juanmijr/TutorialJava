package version1;

public class Main {

	public static void main(String[] args) {
		Ventana ventana = new Ventana();
		//Carrera carrera = new Carrera();
		
		

	}

}
