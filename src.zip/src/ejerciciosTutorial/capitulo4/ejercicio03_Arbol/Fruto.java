package capítulo4.ejercicio03_Arbol;

public class Fruto extends ComponenteDeArbol {

	/**
	 * @param nombre
	 */
	public Fruto(String nombre) {
		super(nombre);
		// TODO Auto-generated constructor stub
	}

}
