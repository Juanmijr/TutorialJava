package cap�tulo5;

import javax.swing.JOptionPane;

public class Ejercicio0B1 {

	public static void main(String[] args) {
		
	}
		int array[]= new int [150];
		int suma=0; 
		int mayor=0;
		int menor=0;

			for (int i = 0 ; i<array.length ; i++) {
				array[i]= ((int)Math.round(Math.random()*(100)));
			}
			mayor = array[0];
			menor = array[0];
			suma = array[0];
				for (int i = 0; i < array.length; i++) {
					suma+=array[i];
					if (array[i]<mayor) {
						array[i] = mayor;
					}
					if (array[i]>mayor) {
						mayor = array[i];
					}
					if (array[i]<menor) {
						menor = array[i];
					}
					if (array[i]>menor) {
						array[i] = menor;
					}
					
	}
				JOptionPane.showMessageDialog(null, "La suma de los n�meros es = " + suma);
				JOptionPane.showMessageDialog(null,"La media de los n�meros es: " + ((float) suma/150));
				JOptionPane.showMessageDialog(null, "El n�mero mayor es: " + mayor);
				JOptionPane.showMessageDialog(null, "El n�mero menor es: " + menor);
				
	}

