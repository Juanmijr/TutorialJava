package bloque05;

public class Linea {

}
