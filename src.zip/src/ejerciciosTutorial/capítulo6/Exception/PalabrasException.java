package ejerciciosTutorial.capítulo6.Exception;

public class PalabrasException extends Exception {

	public PalabrasException(String msg) {
		super (msg);
	}
}
