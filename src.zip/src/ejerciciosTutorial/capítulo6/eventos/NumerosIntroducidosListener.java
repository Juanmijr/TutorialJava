package ejerciciosTutorial.capítulo6.eventos;

public interface NumerosIntroducidosListener {

	public void nuevosNumerosIntroducidos (NumerosIntroducidosEvent newEvent);
}
