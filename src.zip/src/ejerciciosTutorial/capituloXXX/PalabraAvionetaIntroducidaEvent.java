package ejerciciosTutorial.capituloXXX;

public class PalabraAvionetaIntroducidaEvent {
String palabraIntroducida;
	
	public PalabraAvionetaIntroducidaEvent (String palabra) {
		this.palabraIntroducida = palabra;
	}
}
