package ejerciciosTutorial.capituloXXX;

public class PalabraIntroducidaAvionetaEvents {

	int numeroIntroducido;
	
	public NumeroImparIntroducidoAvionetaEvent (int numero) {
		this.numeroIntroducido = numero;
	}
}
