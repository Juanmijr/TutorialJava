package examenes.ExamenCaja_del_supermercado;

public class CambioMenorEvent {

	float dinero; 
	public CambioMenorEvent(float dinero) {
		super();
		// TODO Auto-generated constructor stub
	}
	public float getDinero() {
		return dinero;
	}
	public void setDinero(int dinero) {
		this.dinero = dinero;
	}

	
	
}
