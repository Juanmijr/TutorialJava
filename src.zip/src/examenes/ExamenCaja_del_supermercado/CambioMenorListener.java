package examenes.ExamenCaja_del_supermercado;

public interface CambioMenorListener {

	public void nuevoCambioMenor (CambioMenorEvent event);
}
