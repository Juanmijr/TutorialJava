package capítulo4.ejercicio03_Arbol;

public class Hoja extends ComponenteDeArbol {

	/**
	 * @param nombre
	 */
	public Hoja(String nombre) {
		super(nombre);
		// TODO Auto-generated constructor stub
	}

}
