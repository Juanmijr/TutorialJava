package capitulo4.EjercicioAhorcado.Version1;

public class Principal {
	
	public static void main(String[] args) {
		//Crea la ventana 
		Ventana.getventana();
		//Comienza el juego
		Juego.comienzajuego();
		
	
	
	}
	
	
}
