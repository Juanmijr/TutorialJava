package examenpoker;

public class Jugador {
	public Carta mano []= new Carta [5];
	public String nombre;
	
	public Jugador( String nombre) {
		super();
		this.nombre = nombre;
	} 

	
}
