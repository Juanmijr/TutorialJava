package examen12018;

public class Ejercicio2 {

	public static void main(String[] args) {
		//DECLARAMOS EL ARRAY
		int array[]= new int [100];
		//CREAMOS ARRAY
		for (int i = 99 ; i >=0 ; i--) {
			array[i] = i;
		//IMPRIMIMOS ARRAY
			System.out.print(array[i] + "  ");
		}
	}

}
	
