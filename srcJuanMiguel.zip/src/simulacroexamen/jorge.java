package simulacroexamen;

import javax.swing.JOptionPane;

public class jorge {

	public static void main(String[] args) {
	JOptionPane.showMessageDialog(null, "HOLA JORGE ME CAGO EN TU PECHO");
	JOptionPane.showMessageDialog(null, "NO TE RÍAS ME CAGO EN TODO");
	System.out.println("MADAFACA CALLATE SHSHSHSH");

	}

}
