package ejerciciosTutorial.capítulo6.eventos;

public class NumerosIntroducidosEvent {
	String str;
	public NumerosIntroducidosEvent(String str) {
		super();
		this.str = str;
	}
	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}

	
			
}
