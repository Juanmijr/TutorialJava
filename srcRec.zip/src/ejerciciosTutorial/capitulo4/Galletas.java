package cap�tulo4;



public class Galletas {

	public static void main(String[] args) {
		MoldeGalletas galleta1= new MoldeGalletas (1);
		galleta1.miNumero();
		MoldeGalletas galleta2= new MoldeGalletas (4);
		galleta2.miNumero();
		MoldeGalletas galleta3= new MoldeGalletas (89);
		galleta3.miNumero();
		MoldeGalletas galleta4= new MoldeGalletas (10);
		galleta4.miNumero();
		MoldeGalletas galleta5= new MoldeGalletas (2);
		galleta5.miNumero();

	}

}
