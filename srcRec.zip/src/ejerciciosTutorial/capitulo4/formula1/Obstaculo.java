package capitulo4.formula1;

public abstract class Obstaculo {
	int posicion;
	int valorObstaculo;

	abstract void inicializa();
}
