package cap�tulo1;

public class Principal {

	public static void main(String[] args) {
		//TiposPrimitivos.primerEjemplo();
		TiposPrimitivos.resolucionEcuacionSegundoGrado();
	}

}
