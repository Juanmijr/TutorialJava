package cap�tulo1;

public class KK {

	public static void main(String[] args) {
	if (20>26) 
		System.out.println("El 20 menor que el 26");
		System.out.println("A que es evidente...");
	

	}
}
