package bloque05;

public class ColadeSuper {

}
