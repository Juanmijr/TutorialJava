package ejerciciosTutorial.capituloXXX;

public interface PalabraAvionetaIntroducidaListener {

	public void nuevaPalabraAvionetaIntroducida (PalabraAvionetaIntroducidaEvent event);

}
