package examenes.ExamenCaja_del_supermercado;

public class falloException extends Exception {

	public falloException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public falloException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public falloException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public falloException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public falloException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
