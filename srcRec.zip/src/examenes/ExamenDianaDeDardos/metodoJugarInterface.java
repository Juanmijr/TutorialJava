package examenes.ExamenDianaDeDardos;

import examenes.ExamenCaja_del_supermercado.falloException;

public interface metodoJugarInterface {
	
	public void jugar () throws falloException;

}
