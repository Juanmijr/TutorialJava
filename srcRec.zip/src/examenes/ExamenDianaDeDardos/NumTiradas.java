package examenes.ExamenDianaDeDardos;

public class NumTiradas {
	String descripcion;
	int puntuacion;
	int probabilidad;
	int id;
	
	
	public NumTiradas(int id, String descripcion, int puntuacion, int probabilidad) {
		super();
		this.id=id;
		this.descripcion = descripcion;
		this.puntuacion = puntuacion;
		this.probabilidad = probabilidad;
	}
	
	
}
