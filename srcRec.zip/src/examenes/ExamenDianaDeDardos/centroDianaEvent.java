package examenes.ExamenDianaDeDardos;

public class centroDianaEvent {

	Jugador jugador;
	public centroDianaEvent(Jugador jugador) {
		super();
		// TODO Auto-generated constructor stub
	}
	public Jugador getJugador() {
		return jugador;
	}
	public void setJugador(Jugador jugador) {
		this.jugador = jugador;
	}
	

}
