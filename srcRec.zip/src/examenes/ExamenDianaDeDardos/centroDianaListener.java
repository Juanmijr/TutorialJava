package examenes.ExamenDianaDeDardos;


public interface centroDianaListener {
	public void nuevoCentroDiana (centroDianaEvent event);
}
